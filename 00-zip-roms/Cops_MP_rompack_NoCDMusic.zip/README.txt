## Cops (HYPSEUS SINGE MULTIPLAYER EDITION)

The files in this package should be installed alongside the required game video (m2v) and (ogg) files.

Hypseus Singe version 2.12.1 or above is required for this game.

You will need to place the files from this package into your cops folder, alongside the m2v and ogg files.

Important Note: You will also need to install the CD MP3 tracks within the CD folder within the ZipROM.


For RetroPie users on Raspberry Pi, the folder structure should look like this:

roms
|-- daphne
|    |
|    |-- cops.daphne
|    |    |
|    |    |-- cops.m2v       (New 2-player media)
|    |    |-- cops.ogg       (English Audio)
|    |    |-- cops.zip       (Main LUA ZIP ROM file)
|    |    |-- cops.txt       (Framefile from install zip)
|    |    |-- cops.commands  (Optional)
|    |    |
|    |



for Windows users, the folder structure should look like this:

hypseus
|-- singe
|    |
|    |-- cops
|    |    |
|    |    |-- cops.m2v       (New 2-player media)
|    |    |-- cops.ogg       (English Audio)
|    |    |-- cops.zip       (Main LUA ZIP ROM file)
|    |    |-- cops.txt       (Framefile from install zip)
|    |    |
|    |
